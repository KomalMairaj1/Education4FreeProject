<div class="ui segment"><h4 class="ui header">Integration Info</h4>This functionality depends on site framework, features, database, user and billing systems.</div>';
